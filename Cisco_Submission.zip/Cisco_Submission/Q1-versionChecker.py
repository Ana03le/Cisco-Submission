import unittest

def versionChecker(version1, version2):
    error = "An error occurred:"
    returnValue = 0
    try:
        parts1 = version1.split(".")
        parts2 = version2.split(".")
    except:
        print(error + " unable to compare " + version1 + " and " + version2)
#Adding trailing zeros for compare versions
    d = len(parts2) - len(parts1)
    parts1 = parts1 + [0]*d
    parts2 = parts2 + [0]*-d
    i=0

    while(i<len(parts1)):
    #for i in range(len(parts1) - 1):
        if int(parts1[i]) < int(parts2[i]):
            returnValue = -1
            break     

        elif int(parts1[i]) > int(parts2[i]):
            returnValue = 1
            break

        i+=1

    return returnValue

class TestVersionChecker(unittest.TestCase):

    def test_single_number(self):
        self.assertEqual(versionChecker("5", "5.0"), 0)

    def test_less_than(self):
        self.assertEqual(versionChecker("4.0", "5.0"), -1)

    def test_greater_than(self):
        self.assertEqual(versionChecker("2.0", "1.0"), 1)

    def test_equal(self):
        self.assertEqual(versionChecker("2.0.1", "2.0"), 1)

if __name__ == '__main__':
    print(versionChecker("5.2","5.02"))
    unittest.main()