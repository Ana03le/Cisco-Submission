/* Function to create the output row for table */
function outputTheRow(Name,Description,Value)
{


	{
		document.write("<tr>");

		document.write("<td>");
		document.write(Name);
		document.write("</td>");

		document.write("<td>");
		document.write(Description);
		document.write("</td>");

		document.write("<td>");
		document.write(Value);
		document.write("</td>");

		document.write("</tr>");

		}

}
