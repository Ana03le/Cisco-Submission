var NetworkObject=[]
NetworkObject[0]={Name:"VPN Server", Description:"Virtual System", Value:"192.168.1.66"};
NetworkObject[1]={Name:"VPN ", Description:"New Virtual System", Value:"192.168.1.70"};






